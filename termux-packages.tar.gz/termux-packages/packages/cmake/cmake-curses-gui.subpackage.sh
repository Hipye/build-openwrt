TERMUX_SUBPKG_INCLUDE="bin/ccmake"
TERMUX_SUBPKG_DESCRIPTION="Curses based user interface for CMake (ccmake)"
TERMUX_SUBPKG_DEPENDS="ncurses-ui-libs"
