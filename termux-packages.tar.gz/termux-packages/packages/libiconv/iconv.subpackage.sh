TERMUX_SUBPKG_INCLUDE="bin/iconv"
TERMUX_SUBPKG_DESCRIPTION="Utility converting between different character encodings"
