TERMUX_SUBPKG_DESCRIPTION="High-level loop and data-locality optimizer for clang"
TERMUX_SUBPKG_INCLUDE="
include/polly/
lib/cmake/polly/
lib/LLVMPolly.so
"
