TERMUX_SUBPKG_DESCRIPTION="Git repository browser"
TERMUX_SUBPKG_DEPENDS="tk"
TERMUX_SUBPKG_INCLUDE="
bin/gitk
share/gitk
share/man/man1/gitk.1*
"
