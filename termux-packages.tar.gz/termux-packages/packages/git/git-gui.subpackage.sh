TERMUX_SUBPKG_DESCRIPTION="A graphical interface to Git"
TERMUX_SUBPKG_DEPENDS="tk"
TERMUX_SUBPKG_INCLUDE="
libexec/git-core/git-gui
libexec/git-core/git-gui--askpass
share/git-gui
share/man/man1/git-gui.1.gz
"
