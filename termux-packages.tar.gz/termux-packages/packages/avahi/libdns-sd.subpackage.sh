TERMUX_SUBPKG_INCLUDE="
include/avahi-compat-libdns_sd/
include/dns_sd.h
lib/libdns_sd.so
lib/pkgconfig/avahi-compat-libdns_sd.pc
"
TERMUX_SUBPKG_DESCRIPTION="Compatibility layer for libdns_sd"
