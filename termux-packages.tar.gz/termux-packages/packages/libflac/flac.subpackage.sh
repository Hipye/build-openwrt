TERMUX_SUBPKG_INCLUDE="bin/flac bin/metaflac share/man/man1"
TERMUX_SUBPKG_DESCRIPTION="FLAC (Free Lossless Audio Codec) command-line tool"
