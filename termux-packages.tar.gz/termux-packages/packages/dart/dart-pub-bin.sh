# Executables installed with 'pub global activate' are available
# in directory $HOME/.pub-cache/bin.
export PATH="$HOME/.pub-cache/bin:$PATH"
