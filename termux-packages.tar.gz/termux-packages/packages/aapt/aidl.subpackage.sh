TERMUX_SUBPKG_INCLUDE="bin/aidl"
TERMUX_SUBPKG_DESCRIPTION="Android Interface Definition Language (AIDL)"
TERMUX_SUBPKG_DEPENDS="googletest"
