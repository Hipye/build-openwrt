# Sponsors and Backers

- [Become a sponsor or backer at Patreon](https://www.patreon.com/termux)

- [Donate to Termux using PayPal or Bitcoin](https://termux.com/donate.html)

# Backers

- ✌ Frank Buschmann

- Nathan Paul Simons

- Dara Adib
