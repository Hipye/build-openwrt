TERMUX_PKG_HOMEPAGE=http://tinyfugue.sourceforge.net/
TERMUX_PKG_DESCRIPTION="Flexible, screen-oriented MUD client"
TERMUX_PKG_VERSION=5.0~beta8
TERMUX_PKG_SRCURL=http://downloads.sourceforge.net/project/tinyfugue/tinyfugue/5.0%20beta%208/tf-50b8.tar.gz
TERMUX_PKG_BUILD_IN_SRC=true
# TERMUX_PKG_DEPENDS="pcre, openssl, libuuid"
# TERMUX_PKG_EXTRA_CONFIGURE_ARGS="--with-ssl=openssl --disable-iri"
