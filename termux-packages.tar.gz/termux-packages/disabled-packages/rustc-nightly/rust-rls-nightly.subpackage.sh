TERMUX_SUBPKG_DESCRIPTION="server that provides IDEs, editors, and other tools with information about Rust programs"
TERMUX_SUBPKG_INCLUDE="opt/rust-nightly/bin/rls opt/rust-nightly/share/doc/rls"
TERMUX_PKG_DEPENDS="rustc-nightly"
