TERMUX_SUBPKG_DESCRIPTION="An interpreter for Rust's mid-level intermediate representation"
TERMUX_SUBPKG_INCLUDE="opt/rust-nightly/bin/cargo-miri opt/rust-nightly/bin/miri opt/rust-nightlyshare/doc/miri"
TERMUX_SUBPKG_DEPENDS="rustc-nightly"

